load("/Users/samanthabanos/Desktop/UCSB/PSTAT 131/sleep-project/models/sleep_model_setup.rda")

library(tidymodels)
library(ranger)

set.seed(123)

# set up model, tuning mtry, min_n, and trees, while importance="impurity"
rf_mod <- rand_forest(
  mtry = tune(),
  min_n = tune(),
  trees = tune()) %>%
  set_engine("ranger", importance = "impurity") %>%
  set_mode("classification")

# create workflow
rf_wf <- workflow() %>%
  add_recipe(sleep_recipe) %>%
  add_model(rf_mod)

# create tuning grid and tune using 5-fold cv
rf_grid <- grid_regular(
  mtry(range = c(2, 10)),
  min_n(range = c(2, 10)),
  trees(range = c(100, 1000)),  
  levels = 6                  
)

rf_res <- tune_grid(
  rf_wf,
  resamples = cv_folds,
  grid = rf_grid,
  metrics = metric_set(roc_auc,accuracy)
)

# select best parameters, finalize and fit model
rf_best <- select_best(rf_res, metric = "roc_auc")
rf_final <- finalize_workflow(rf_wf, rf_best)
rf_final_fit <- fit(rf_final, data = sleep_train)

# save model results

save(rf_res, rf_final_fit,
     file = "/Users/samanthabanos/Desktop/UCSB/PSTAT 131/sleep-project/models/random_forest_model.rda")
