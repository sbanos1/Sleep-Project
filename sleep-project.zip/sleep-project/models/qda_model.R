load("/Users/samanthabanos/Desktop/UCSB/PSTAT 131/sleep-project/models/sleep_model_setup.rda")

library(tidymodels)
library(MASS)

set.seed(123)

qda_mod <- discrim_quad() %>%
  set_engine("MASS") %>%
  set_mode("classification")

# create workflow
qda_wf <- workflow() %>%
  add_recipe(sleep_recipe) %>%
  add_model(qda_mod)

# fit model to training data
qda_fit <- fit(qda_wf, data = sleep_train)

# save model
save(qda_fit, file = "/Users/samanthabanos/Desktop/UCSB/PSTAT 131/sleep-project/models/qda_model.rda")
