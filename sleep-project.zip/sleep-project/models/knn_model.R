load("/Users/samanthabanos/Desktop/UCSB/PSTAT 131/sleep-project/models/sleep_model_setup.rda")

library(tidymodels)

set.seed(123)

# create knn model tuning neighbors
knn_mod <- nearest_neighbor(
  neighbors = tune()
) %>%
  set_engine("kknn") %>%
  set_mode("classification")

# create workflow
knn_wf <- workflow() %>%
  add_recipe(sleep_recipe) %>%
  add_model(knn_mod)

# tune grid
knn_grid <- grid_regular(
  neighbors(range = c(1, 25)),  
  levels = 10                   
)

# tune model using 5-fold cv
knn_res <- tune_grid(
  knn_wf,
  resamples = cv_folds,
  grid = knn_grid,
  metrics = metric_set(roc_auc)
)

# select best number of neighbors and finalaize and fit to training data
knn_best <- select_best(knn_res, metric = "roc_auc")
knn_final <- finalize_workflow(knn_wf, knn_best)
knn_final_fit <- fit(knn_final, data = sleep_train)

# save model results
save(knn_res, knn_final_fit,
     file = "/Users/samanthabanos/Desktop/UCSB/PSTAT 131/sleep-project/models/knn_model.rda")