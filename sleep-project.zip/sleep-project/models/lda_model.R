load("/Users/samanthabanos/Desktop/UCSB/PSTAT 131/sleep-project/models/sleep_model_setup.rda")

library(tidymodels)
library(MASS)

set.seed(123)

lda_mod <- discrim_linear() %>%
  set_engine("MASS") %>%
  set_mode("classification")

# create workflow
lda_wf <- workflow() %>%
  add_recipe(sleep_recipe) %>%
  add_model(lda_mod)

# fit model to training data
lda_fit <- fit(lda_wf, data = sleep_train)

# save model
save(lda_fit, file = "/Users/samanthabanos/Desktop/UCSB/PSTAT 131/sleep-project/models/lda_model.rda")
