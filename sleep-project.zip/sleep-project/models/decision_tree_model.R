load("/Users/samanthabanos/Desktop/UCSB/PSTAT 131/sleep-project/models/sleep_model_setup.rda")

library(tidymodels)
library(rpart)

set.seed(123)

# set up model tuning cost_complexity
tree_mod <- decision_tree(
  cost_complexity = tune()
) %>%
  set_engine("rpart") %>%
  set_mode("classification")

# set up workflow
tree_wf <- workflow() %>%
  add_recipe(sleep_recipe) %>%
  add_model(tree_mod)

# grid of cost_complexity models
tree_grid <- grid_regular(
  cost_complexity(range = c(-4, -1)),  # 0.0001 to 0.1
  levels = 10
)

# tuning model
tree_res <- tune_grid(
  tree_wf,
  resamples = cv_folds,
  grid = tree_grid,
  metrics = metric_set(roc_auc, accuracy)
)

# select best decision tree
tree_best <- select_best(tree_res, metric = "roc_auc")

# finalize workflow and fit on training data
tree_final <- finalize_workflow(tree_wf, tree_best)
tree_final_fit <- fit(tree_final, data = sleep_train)

# save model
save(tree_res, tree_final_fit,
     file = "/Users/samanthabanos/Desktop/UCSB/PSTAT 131/sleep-project/models/decision_tree_model.rda")