load("/Users/samanthabanos/Desktop/UCSB/PSTAT 131/sleep-project/models/sleep_model_setup.rda")

library(tidymodels)
library(glmnet)

enet_mod <- multinom_reg(penalty = tune(), mixture = tune()) %>%
  set_engine("glmnet") %>%
  set_mode("classification")

# create workflow

enet_wf <- workflow() %>%
  add_recipe(sleep_recipe) %>%
  add_model(enet_mod)

# create tuning grid
enet_grid <- grid_regular(
  penalty(range = c(-4,0)),
  mixture(range=c(0,1)),
  levels=5)

# tune using cv_folds
enet_res <- tune_grid(
  enet_wf,
  resamples = cv_folds,
  grid = enet_grid,
  metrics = metric_set(roc_auc, accuracy)
)

# select best penalty
enet_best <- select_best(enet_res, metric = "roc_auc")

# finalize model and fit on training data

enet_final <- finalize_workflow(enet_wf, enet_best)
enet_final_fit <- fit(enet_final, data = sleep_train)


# save fitted model
save(enet_fit,enet_final_fit, file = "/Users/samanthabanos/Desktop/UCSB/PSTAT 131/sleep-project/models/logistic_model.rda")

